# -*- coding: utf-8 -*-
r"""
NCL
################################################
Reference:
    Zihan Lin*, Changxin Tian*, Yupeng Hou*, Wayne Xin Zhao. "Improving Graph Collaborative Filtering with Neighborhood-enriched Contrastive Learning." in WWW 2022.
"""

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn.functional as F

import faiss
from recbole.model.abstract_recommender import GeneralRecommender
from recbole.model.init import xavier_uniform_initialization
from recbole.model.loss import BPRLoss, EmbLoss
from recbole.utils import InputType

import math
import torch.nn as nn

import json

def gelu(x):
    """Implementation of the gelu activation function.
        For information: OpenAI GPT's gelu is slightly different
        (and gives slightly different results):
        0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) *
        (x + 0.044715 * torch.pow(x, 3))))
        Also see https://arxiv.org/abs/1606.08415
    """
    return x * 0.5 * (1.0 + torch.erf(x / math.sqrt(2.0)))

def swish(x):
    return x * torch.sigmoid(x)
ACT2FN = {"gelu": gelu, "relu": F.relu, "swish": swish}

class MetaAug(nn.Module):
    def __init__(self,layers, dropout=0., activation='relu', ln=False, init_method=None,use_gumbel=False):
        super(MetaAug, self).__init__()
        # self.use_gumbel=use_gumbel
        # self.dense_1=nn.Linear(layers[0],layers[1])


        # self.actfunction=ACT2FN[activation]
        # self.ln=ln
        # self.dense_2=nn.Linear(layers[1],layers[2])
        # self.dense_3=nn.Linear(layers[1],layers[2])
        # self.dropout=dropout
        self.classifier1 = nn.Sequential(
            nn.Linear(layers[0],layers[1]),
            nn.ReLU(inplace=True),
            nn.Linear(layers[1],layers[2]),


        )
    def dense_layer_ff(self, input, weights, index):
        net = F.linear(input, weights['classifier{:d}.0.weight'.format(index)], weights['classifier{:d}.0.bias'.format(index)])
        net = F.relu(net, inplace=True)
        net = F.linear(net, weights['classifier{:d}.2.weight'.format(index)], weights['classifier{:d}.2.bias'.format(index)])
        net = F.linear(net, weights['classifier{:d}.3.weight'.format(index)], weights['classifier{:d}.3.bias'.format(index)])

        return net




    def forward(self,input,weights=None):
        if weights is None:
            output=self.classifier1(input)
        else:
            output=self.dense_layer_ff(input,weights,1)

        return output

class NCL(GeneralRecommender):
    input_type = InputType.PAIRWISE

    def __init__(self, config, dataset):
        super(NCL, self).__init__(config, dataset)

        # load dataset info
        self.interaction_matrix = dataset.inter_matrix(form='coo').astype(np.float32)

        # load parameters info
        self.latent_dim = config['embedding_size']  # int type: the embedding size of the base model
        self.n_layers = config['n_layers']          # int type: the layer num of the base model
        self.reg_weight = config['reg_weight']      # float32 type: the weight decay for l2 normalization

        self.ssl_temp = config['ssl_temp']
        self.ssl_reg = config['ssl_reg']
        self.hyper_layers = config['hyper_layers']

        self.alpha = config['alpha']

        self.proto_reg = config['proto_reg']
        self.k = config['num_clusters']

        self.dataset = config["dataset"]
        # define layers and loss




        # weight = torch.tensor(self.textfeat)
        #
        # mlp1 = nn.Linear(weight.shape[1], self.latent_dim)
        # weight = mlp1(weight)

        ls_catgory, len_ls1 = self.text_feat()
        ls_emb = self.ls_emb(ls_catgory, len_ls1)



        # define layers and loss
        self.user_embedding = torch.nn.Embedding(num_embeddings=self.n_users, embedding_dim=self.latent_dim * 2)
        # self.item_embedding = torch.nn.Embedding(num_embeddings=self.n_items, embedding_dim=self.latent_dim)


        self.item_embedding_id = torch.nn.Embedding(num_embeddings=self.n_items, embedding_dim=self.latent_dim).requires_grad_(False)
        # mixed_emb=self.item_embedding_id.weight+ls_emb

        mixed_emb = torch.cat([self.item_embedding_id.weight, ls_emb], dim=1)

        self.item_embedding = nn.Embedding.from_pretrained(mixed_emb, freeze=False)




        self.meta_a = MetaAug(layers=[128,64,128], dropout=0., activation='relu', ln=False, init_method=None,
                              use_gumbel=False).to(self.device)


        self.mf_loss = BPRLoss()
        self.reg_loss = EmbLoss()

        # storage variables for full sort evaluation acceleration
        self.restore_user_e = None
        self.restore_item_e = None

        self.norm_adj_mat = self.get_norm_adj_mat().to(self.device)

        # parameters initialization
        self.apply(xavier_uniform_initialization)
        self.other_parameter_name = ['restore_user_e', 'restore_item_e']

        self.user_centroids = None
        self.user_2cluster = None
        self.item_centroids = None
        self.item_2cluster = None

    def ls_emb(self,ls,len_ls1):
        lss=[]
        aa=[0. for i in range(self.latent_dim)]
        lss.append(aa)

        cat_emb=torch.nn.Embedding(len_ls1,self.latent_dim).requires_grad_(False)
        cat_emb=cat_emb.weight
        for i in ls:
            lss.append(cat_emb[i].tolist())

        lss_emb=torch.tensor(lss)
        return lss_emb


    def text_feat(self):
        # model = SentenceTransformer('paraphrase-albert-small-v2')

        with open('dataset' + '/' + self.dataset + '/' + 'id-newid.json', 'r') as file:
            content = file.read()

        dic1 = json.loads(content)  # 将json格式文件转化为python的字典文件
        dic2 = {}
        with open('dataset' + '/' + self.dataset + '/' + self.dataset + '.item', 'r') as f:
            k = 0
            dic3={}
            while True:
                k = k + 1
                if (k % 10000 == 0): print(k)
                a = f.readline()
                if a == '': break
                a = a.split('\t')
                id = a[0]
                if (id in dic1.keys()):

                    dic2[dic1[id]] = a[3].strip()
                    if a[3].strip() not in dic3.keys():
                        dic3[a[3].strip()]=1
                    else:
                        dic3[a[3].strip()]+=1

        lst = []
        ls1=list(dic3.keys())
        print("ls1的长度为：",len(ls1))

        ls_cate=[]
        for i in range(1, len(dic2) + 1):
            lst.append(dic2[i])
            for j in range(len(ls1)+1):
                if ls1[j]==dic2[i]:
                    ls_cate.append(j)
                    break
            if (i % 100 == 0): print(i)
        print("ls_cate的长度为：",len(ls_cate))


        return ls_cate,len(ls1)

    def e_step(self):
        user_embeddings = self.user_embedding.weight.detach().cpu().numpy()
        item_embeddings = self.item_embedding.weight.detach().cpu().numpy()
        # item_embeddings_id = self.item_embedding_id.weight.detach().cpu().numpy()
        self.user_centroids, self.user_2cluster = self.run_kmeans(user_embeddings)
        self.item_centroids, self.item_2cluster = self.run_kmeans(item_embeddings)
        # self.item_centroids_id, self.item_2cluster_id = self.run_kmeans(item_embeddings_id)

    def run_kmeans(self, x):
        """Run K-means algorithm to get k clusters of the input tensor x
        """
        kmeans = faiss.Kmeans(d=self.latent_dim * 2, k=self.k, gpu=True)
        kmeans.train(x)
        cluster_cents = kmeans.centroids

        _, I = kmeans.index.search(x, 1)

        # convert to cuda Tensors for broadcast
        centroids = torch.Tensor(cluster_cents).to(self.device)
        centroids = F.normalize(centroids, p=2, dim=1)

        node2cluster = torch.LongTensor(I).squeeze().to(self.device)
        return centroids, node2cluster

    def get_norm_adj_mat(self):
        r"""Get the normalized interaction matrix of users and items.

        Construct the square matrix from the training data and normalize it
        using the laplace matrix.

        .. math::
            A_{hat} = D^{-0.5} \times A \times D^{-0.5}

        Returns:
            Sparse tensor of the normalized interaction matrix.
        """
        # build adj matrix
        A = sp.dok_matrix((self.n_users + self.n_items, self.n_users + self.n_items), dtype=np.float32)
        inter_M = self.interaction_matrix
        inter_M_t = self.interaction_matrix.transpose()
        data_dict = dict(zip(zip(inter_M.row, inter_M.col + self.n_users), [1] * inter_M.nnz))
        data_dict.update(dict(zip(zip(inter_M_t.row + self.n_users, inter_M_t.col), [1] * inter_M_t.nnz)))
        A._update(data_dict)
        # norm adj matrix
        sumArr = (A > 0).sum(axis=1)
        # add epsilon to avoid divide by zero Warning
        diag = np.array(sumArr.flatten())[0] + 1e-7
        diag = np.power(diag, -0.5)
        self.diag = torch.from_numpy(diag).to(self.device)
        D = sp.diags(diag)
        L = D @ A @ D
        # covert norm_adj matrix to tensor
        L = sp.coo_matrix(L)
        row = L.row
        col = L.col
        i = torch.LongTensor([row, col])
        data = torch.FloatTensor(L.data)
        SparseL = torch.sparse.FloatTensor(i, data, torch.Size(L.shape))
        return SparseL

    def get_ego_embeddings(self):
        r"""Get the embedding of users and items and combine to an embedding matrix.

        Returns:
            Tensor of the embedding matrix. Shape of [n_items+n_users, embedding_dim]
        """
        user_embeddings = self.user_embedding.weight
        item_embeddings_feature = self.item_embedding.weight
        # item_embeddings_id = self.item_embedding_id.weight
        #
        # item_embeddings_hybrid=item_embeddings_feature+0.5*item_embeddings_id


        ego_embeddings_feature = torch.cat([user_embeddings, item_embeddings_feature], dim=0)
        # ego_embeddings_id = torch.cat([user_embeddings, item_embeddings_id], dim=0)
        # ego_embeddings_hybrid = torch.cat([user_embeddings, item_embeddings_hybrid], dim=0)
        return ego_embeddings_feature

    def forward(self):
        all_embeddings = self.get_ego_embeddings()
        embeddings_list = [all_embeddings]
        for layer_idx in range(max(self.n_layers, self.hyper_layers*2)):
            all_embeddings = torch.sparse.mm(self.norm_adj_mat, all_embeddings)
            embeddings_list.append(all_embeddings)

        lightgcn_all_embeddings = torch.stack(embeddings_list[:self.n_layers+1], dim=1)
        lightgcn_all_embeddings = torch.mean(lightgcn_all_embeddings, dim=1)

        user_all_embeddings, item_all_embeddings = torch.split(lightgcn_all_embeddings, [self.n_users, self.n_items])
        return user_all_embeddings, item_all_embeddings, embeddings_list


    def forward11(self,aa,bb):
        all_embeddings = torch.cat([aa, bb], dim=0)


        all_embeddings = torch.sparse.mm(self.norm_adj_mat, all_embeddings)






        return all_embeddings



    def ProtoNCE_loss(self, node_embedding, user, item):
        user_embeddings_all, item_embeddings_all = torch.split(node_embedding, [self.n_users, self.n_items])

        user_embeddings = user_embeddings_all[user]     # [B, e]
        norm_user_embeddings = F.normalize(user_embeddings)

        user2cluster = self.user_2cluster[user]     # [B,]
        user2centroids = self.user_centroids[user2cluster]   # [B, e]
        pos_score_user = torch.mul(norm_user_embeddings, user2centroids).sum(dim=1)
        pos_score_user = torch.exp(pos_score_user / self.ssl_temp)
        ttl_score_user = torch.matmul(norm_user_embeddings, self.user_centroids.transpose(0, 1))
        ttl_score_user = torch.exp(ttl_score_user / self.ssl_temp).sum(dim=1)

        proto_nce_loss_user = -torch.log(pos_score_user / ttl_score_user).sum()

        item_embeddings = item_embeddings_all[item]
        norm_item_embeddings = F.normalize(item_embeddings)

        item2cluster = self.item_2cluster[item]  # [B, ]
        item2centroids = self.item_centroids[item2cluster]  # [B, e]
        pos_score_item = torch.mul(norm_item_embeddings, item2centroids).sum(dim=1)
        pos_score_item = torch.exp(pos_score_item / self.ssl_temp)
        ttl_score_item = torch.matmul(norm_item_embeddings, self.item_centroids.transpose(0, 1))
        ttl_score_item = torch.exp(ttl_score_item / self.ssl_temp).sum(dim=1)
        proto_nce_loss_item = -torch.log(pos_score_item / ttl_score_item).sum()

        proto_nce_loss = self.proto_reg * (proto_nce_loss_user + proto_nce_loss_item)
        return proto_nce_loss

    def ssl_layer_loss(self, current_embedding, previous_embedding, user, item):
        current_user_embeddings, current_item_embeddings = torch.split(current_embedding, [self.n_users, self.n_items])
        previous_user_embeddings_all, previous_item_embeddings_all = torch.split(previous_embedding, [self.n_users, self.n_items])

        current_user_embeddings = current_user_embeddings[user]
        previous_user_embeddings = previous_user_embeddings_all[user]
        norm_user_emb1 = F.normalize(current_user_embeddings)
        norm_user_emb2 = F.normalize(previous_user_embeddings)
        norm_all_user_emb = F.normalize(previous_user_embeddings_all)
        pos_score_user = torch.mul(norm_user_emb1, norm_user_emb2).sum(dim=1)
        ttl_score_user = torch.matmul(norm_user_emb1, norm_all_user_emb.transpose(0, 1))
        pos_score_user = torch.exp(pos_score_user / self.ssl_temp)
        ttl_score_user = torch.exp(ttl_score_user / self.ssl_temp).sum(dim=1)

        ssl_loss_user = -torch.log(pos_score_user / ttl_score_user).sum()

        current_item_embeddings = current_item_embeddings[item]
        previous_item_embeddings = previous_item_embeddings_all[item]
        norm_item_emb1 = F.normalize(current_item_embeddings)
        norm_item_emb2 = F.normalize(previous_item_embeddings)
        norm_all_item_emb = F.normalize(previous_item_embeddings_all)
        pos_score_item = torch.mul(norm_item_emb1, norm_item_emb2).sum(dim=1)
        ttl_score_item = torch.matmul(norm_item_emb1, norm_all_item_emb.transpose(0, 1))
        pos_score_item = torch.exp(pos_score_item / self.ssl_temp)
        ttl_score_item = torch.exp(ttl_score_item / self.ssl_temp).sum(dim=1)

        ssl_loss_item = -torch.log(pos_score_item / ttl_score_item).sum()

        ssl_loss = self.ssl_reg * (ssl_loss_user + self.alpha * ssl_loss_item)
        return ssl_loss


    def cl_loss(self, current_embedding, previous_embedding, user, item):

        user=torch.unique(user)
        item=torch.unique(item)

        current_user_embeddings, current_item_embeddings = torch.split(current_embedding, [self.n_users, self.n_items])
        previous_user_embeddings_all, previous_item_embeddings_all = torch.split(previous_embedding, [self.n_users, self.n_items])

        current_user_embeddings = current_user_embeddings[user]
        previous_user_embeddings = previous_user_embeddings_all[user]

        norm_user_emb1 = F.normalize(current_user_embeddings)
        norm_user_emb2 = F.normalize(previous_user_embeddings)


        pos_score_user = torch.mul(norm_user_emb1, norm_user_emb2).sum(dim=1)
        ttl_score_user = torch.matmul(norm_user_emb1, norm_user_emb2.transpose(0, 1))

        pos_score_user = torch.exp(pos_score_user / self.ssl_temp)
        ttl_score_user = torch.exp(ttl_score_user / self.ssl_temp).sum(dim=1)

        ssl_loss_user = -torch.log(pos_score_user / ttl_score_user).sum()


        current_item_embeddings = current_item_embeddings[item]
        previous_item_embeddings = previous_item_embeddings_all[item]
        norm_item_emb1 = F.normalize(current_item_embeddings)
        norm_item_emb2 = F.normalize(previous_item_embeddings)

        pos_score_item = torch.mul(norm_item_emb1, norm_item_emb2).sum(dim=1)
        ttl_score_item = torch.matmul(norm_item_emb1, norm_item_emb2.transpose(0, 1))
        pos_score_item = torch.exp(pos_score_item / self.ssl_temp)
        ttl_score_item = torch.exp(ttl_score_item / self.ssl_temp).sum(dim=1)

        ssl_loss_item = -torch.log(pos_score_item / ttl_score_item).sum()

        ssl_loss = self.ssl_reg * (ssl_loss_user + self.alpha * ssl_loss_item)
        return ssl_loss

    def cl_loss_margin(self, current_embedding, previous_embedding, user, item,mode1):



        current_user_embeddings, current_item_embeddings = torch.split(current_embedding, [self.n_users, self.n_items])
        previous_user_embeddings_all, previous_item_embeddings_all = torch.split(previous_embedding,
                                                                                 [self.n_users, self.n_items])

        current_user_embeddings = current_user_embeddings[user]
        previous_user_embeddings = previous_user_embeddings_all[user]

        norm_user_emb1 = F.normalize(current_user_embeddings)
        norm_user_emb2 = F.normalize(previous_user_embeddings)



        pos_score_user = torch.mul(norm_user_emb1, norm_user_emb2).sum(dim=1)
        ttl_score_user = torch.matmul(norm_user_emb1, norm_user_emb2.transpose(0, 1))


        # print('pos_score_user',pos_score_user.shape)
        # print('ttl_score_user',ttl_score_user.shape)
        #
        # print('ttl_score_user[:, None]',ttl_score_user[:, None].shape)
        my_margin = 0.8
        margin_loss = torch.nn.MarginRankingLoss(margin=my_margin, reduce=False)

        margin_label1 = -1 * torch.ones_like(ttl_score_user).cuda()

        ssl_logits_user = margin_loss(ttl_score_user, pos_score_user[:, None], margin_label1)

        clogits_user = torch.logsumexp(ssl_logits_user / self.ssl_temp, dim=1)

        ssl_loss_user=torch.sum(clogits_user)

        mask_margin_user=0
        mask_margin_item=0

        margin_loss_sum=torch.tensor(0).to(self.device)

        if mode1==2:
            my_margin_2 = 0.95
            lbl_z = torch.tensor([0.]).cuda()
            mask_margin_user1 = torch.max((pos_score_user[:, None].detach() - ttl_score_user - my_margin_2), lbl_z)
            mask_margin_user = torch.logsumexp(mask_margin_user1 / self.ssl_temp, dim=1)


        current_item_embeddings = current_item_embeddings[item]
        previous_item_embeddings = previous_item_embeddings_all[item]
        norm_item_emb1 = F.normalize(current_item_embeddings)
        norm_item_emb2 = F.normalize(previous_item_embeddings)

        pos_score_item = torch.mul(norm_item_emb1, norm_item_emb2).sum(dim=1)
        ttl_score_item = torch.matmul(norm_item_emb1, norm_item_emb2.transpose(0, 1))


        margin_label11= -1 * torch.ones_like(pos_score_item).cuda()

        ssl_logits_item = margin_loss(ttl_score_item, pos_score_item[:, None], margin_label11)
        clogits_item = torch.logsumexp(ssl_logits_item / self.ssl_temp, dim=1)
        ssl_loss_item=torch.sum(clogits_item)

        if mode1==2:
            my_margin_2 = 0.95
            lbl_z = torch.tensor([0.]).cuda()
            mask_margin_item1 = torch.max((pos_score_item[:, None].detach() - ttl_score_item - my_margin_2), lbl_z)
            mask_margin_item = torch.logsumexp(mask_margin_item1 / self.ssl_temp, dim=1)
        if mode1==2:
            margin_loss_sum=torch.sum(mask_margin_user) + torch.sum(mask_margin_item)

        ssl_loss = self.ssl_reg * (ssl_loss_user + self.alpha * ssl_loss_item + self.alpha * margin_loss_sum )
        return ssl_loss



    def calculate_loss(self, interaction,meta_aug=None, mode=None):
        # clear the storage variable when training
        if self.restore_user_e is not None or self.restore_item_e is not None:
            self.restore_user_e, self.restore_item_e = None, None

        user = interaction[self.USER_ID]
        pos_item = interaction[self.ITEM_ID]
        neg_item = interaction[self.NEG_ITEM_ID]




        user_anchor=self.meta_a(self.user_embedding.weight)
        item_anchor=self.meta_a(self.item_embedding.weight)

        ego_embeddings_anchor = torch.cat([user_anchor, item_anchor], dim=0)

        all_embeddings_neighbor=self.forward11(user_anchor,item_anchor)

        sugrl_loss1=self.cl_loss_margin(all_embeddings_neighbor,ego_embeddings_anchor,user,pos_item,1)

        user_all_embeddings, item_all_embeddings, embeddings_list = self.forward()




        center_embedding = embeddings_list[0]
        context_embedding = embeddings_list[self.hyper_layers * 2]


## -----------------Meta----------------------
        meta1,meta2=meta_aug

        user_gcn_emb=meta1(user_all_embeddings)
        item_gcn_emb=meta1(item_all_embeddings)


        emb_gcn_pos2 = torch.cat([user_all_embeddings, item_all_embeddings], dim=0)
        emb_gcn_pos2_meta = torch.cat([user_gcn_emb, item_gcn_emb], dim=0)

        ssl_loss_ori = self.ssl_layer_loss(context_embedding, center_embedding, user, pos_item)

        sugrl_loss2 = self.cl_loss_margin(emb_gcn_pos2,ego_embeddings_anchor,user,pos_item,2)
        sugrl_loss2_meta = self.cl_loss_margin(emb_gcn_pos2_meta,ego_embeddings_anchor,user,pos_item,2)


        ssl_loss =ssl_loss_ori+0.2*(sugrl_loss1+sugrl_loss2+sugrl_loss2_meta)

        proto_loss = self.ProtoNCE_loss(center_embedding, user, pos_item)

        u_embeddings = user_all_embeddings[user]
        pos_embeddings = item_all_embeddings[pos_item]
        neg_embeddings = item_all_embeddings[neg_item]

        # calculate BPR Loss
        pos_scores = torch.mul(u_embeddings, pos_embeddings).sum(dim=1)
        neg_scores = torch.mul(u_embeddings, neg_embeddings).sum(dim=1)

        mf_loss = self.mf_loss(pos_scores, neg_scores)

        u_ego_embeddings = self.user_embedding(user)
        pos_ego_embeddings = self.item_embedding(pos_item)
        neg_ego_embeddings = self.item_embedding(neg_item)

        reg_loss = self.reg_loss(u_ego_embeddings, pos_ego_embeddings, neg_ego_embeddings)

        return mf_loss + self.reg_weight * reg_loss, ssl_loss,proto_loss

    def predict(self, interaction):
        user = interaction[self.USER_ID]
        item = interaction[self.ITEM_ID]

        user_all_embeddings, item_all_embeddings, embeddings_list = self.forward()

        u_embeddings = user_all_embeddings[user]
        i_embeddings = item_all_embeddings[item]
        scores = torch.mul(u_embeddings, i_embeddings).sum(dim=1)
        return scores

    def full_sort_predict(self, interaction):
        user = interaction[self.USER_ID]
        if self.restore_user_e is None or self.restore_item_e is None:
            self.restore_user_e, self.restore_item_e, embedding_list = self.forward()
        # get user embedding from storage variable
        u_embeddings = self.restore_user_e[user]

        # dot with all item embedding to accelerate
        scores = torch.matmul(u_embeddings, self.restore_item_e.transpose(0, 1))

        return scores.view(-1)
